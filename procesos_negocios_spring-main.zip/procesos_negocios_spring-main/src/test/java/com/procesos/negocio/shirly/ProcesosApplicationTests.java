package com.procesos.negocio.shirly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcesosApplicationTests {

	@Test
	void contextLoads() {
	}

}
